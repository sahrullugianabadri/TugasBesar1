<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('books')->insert([
           
            'title' =>'cinta',
            'author'=>'jasmine',
            'year'=>'2022',
           'publisher'=> 'PT.Syania',
           'city' => 'cianjur',
           'cover' =>'cover.jpg',
           'bookshelf_id' => 1
            
        ]);
    }
}
